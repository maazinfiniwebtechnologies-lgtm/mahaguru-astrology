import { pgTable, text, integer, boolean, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const videoReviews = pgTable("video_reviews", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  youtubeUrl: text("youtube_url").notNull(),
  displayOrder: integer("display_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const insertVideoReviewSchema = createInsertSchema(videoReviews).omit({ id: true });
export type VideoReview = typeof videoReviews.$inferSelect;
export type InsertVideoReview = z.infer<typeof insertVideoReviewSchema>;
