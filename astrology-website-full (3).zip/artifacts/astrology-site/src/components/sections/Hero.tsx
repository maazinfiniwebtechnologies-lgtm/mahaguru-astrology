import { Phone, Shield, Clock, CheckCircle } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";
import zodiacImg from "@assets/generated_images/golden_zodiac_wheel_mandala_8312.png";

const panditImg = "/pandit-ji.png";

const STARS = [
  { top: "8%",  left: "4%",  size: 3, delay: 0 },
  { top: "18%", left: "12%", size: 2, delay: 0.5 },
  { top: "32%", left: "6%",  size: 4, delay: 1 },
  { top: "55%", left: "2%",  size: 2, delay: 0.3 },
  { top: "72%", left: "16%", size: 3, delay: 0.8 },
  { top: "14%", left: "38%", size: 2, delay: 1.2 },
  { top: "4%",  left: "52%", size: 3, delay: 0.6 },
  { top: "78%", left: "43%", size: 2, delay: 0.2 },
  { top: "88%", left: "58%", size: 4, delay: 1.5 },
  { top: "22%", left: "70%", size: 2, delay: 0.9 },
  { top: "48%", left: "82%", size: 3, delay: 0.4 },
  { top: "68%", left: "76%", size: 2, delay: 1.1 },
  { top: "6%",  left: "86%", size: 3, delay: 0.7 },
  { top: "40%", left: "22%", size: 2, delay: 1.3 },
  { top: "62%", left: "30%", size: 3, delay: 0.1 },
];

export function Hero() {
  return (
    <section
      className="relative flex items-stretch overflow-hidden"
      style={{
        minHeight: "calc(100vh - 100px)",
        background: "linear-gradient(135deg, #0d0020 0%, #1a0035 40%, #280050 70%, #0d0020 100%)",
      }}
      data-testid="section-hero"
    >
      {/* Glowing stars */}
      {STARS.map((s, i) => (
        <span
          key={i}
          className="hero-star"
          style={{
            top: s.top,
            left: s.left,
            width: s.size,
            height: s.size,
            animationDelay: `${s.delay}s`,
          }}
        />
      ))}

      {/* Purple glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 65% 75% at 72% 45%, rgba(140,0,220,0.3) 0%, transparent 65%)",
        }}
      />

      <div className="container mx-auto px-4 py-10 lg:py-0 relative z-10 flex items-center">
        <div className="grid lg:grid-cols-2 gap-0 items-end w-full" style={{ minHeight: "calc(100vh - 100px)" }}>

          {/* ── LEFT ── */}
          <div className="flex flex-col justify-center py-10 lg:py-16 order-2 lg:order-1">
            {/* Badge */}
            <div className="inline-flex mb-5">
              <span className="hero-badge" data-testid="badge-experience">
                ✦ ३५+ वर्षों का अनुभव ✦
              </span>
            </div>

            {/* Main heading */}
            <h1 className="hero-hindi-heading mb-3" data-testid="hero-heading">
              केवल वशीकरण करवाने<br />
              वाले ही संपर्क करे ।
            </h1>

            {/* Sub heading row */}
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="hero-hindi-sub">महागुरु ज्योतिष</span>
              <span style={{ color: "#fff", fontSize: "1.6rem" }}>ᛃ</span>
              <span style={{ color: "#f6d365", fontSize: "1.4rem" }}>✦</span>
            </div>

            {/* Premium line */}
            <h2 className="hero-hindi-small mb-4" data-testid="hero-subheading">
              प्रीमियम ज्योतिषी
            </h2>

            {/* Caption */}
            <p className="hero-hindi-caption mb-7">
              ऑनलाइन एवं ऑफलाइन सेवाएं उपलब्ध हैं
            </p>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-x-5 gap-y-2 mb-8">
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <Shield className="w-4 h-4 text-yellow-400 shrink-0" />
                <span>100% गोपनीयता</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <Clock className="w-4 h-4 text-yellow-400 shrink-0" />
                <span>24/7 सेवा उपलब्ध</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <CheckCircle className="w-4 h-4 text-yellow-400 shrink-0" />
                <span>सटीक समाधान</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="tel:+919849416699"
                className="hero-btn-call"
                data-testid="button-hero-call"
              >
                <Phone className="w-5 h-5" />
                अभी कॉल करें
              </a>
              <a
                href="https://wa.me/919849416699"
                target="_blank"
                rel="noreferrer"
                className="hero-btn-whatsapp"
                data-testid="button-hero-whatsapp"
              >
                <FaWhatsapp className="w-5 h-5" />
                WHATSAPP पर चैट करें
              </a>
            </div>
          </div>

          {/* ── RIGHT — zodiac + pandit ── */}
          <div
            className="relative order-1 lg:order-2 flex items-end justify-center"
            style={{ minHeight: "340px", height: "calc(100vh - 100px)" }}
          >
            {/* Zodiac wheel — centered in right column */}
            <img
              src={zodiacImg}
              alt="Zodiac wheel"
              className="zodiac-wheel absolute"
              style={{
                width: "clamp(280px, 52vw, 580px)",
                height: "clamp(280px, 52vw, 580px)",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                opacity: 0.95,
                filter: "drop-shadow(0 0 50px rgba(180,120,0,0.55))",
              }}
            />

            {/* Pandit ji — full body, sits at bottom */}
            <img
              src={panditImg}
              alt="महागुरु ज्योतिष"
              className="pandit-img"
              style={{
                position: "relative",
                zIndex: 2,
                width: "clamp(220px, 38vw, 460px)",
                height: "auto",
                maxHeight: "90%",
                objectFit: "contain",
                objectPosition: "bottom",
                filter: "drop-shadow(0 0 40px rgba(160,80,255,0.45))",
                marginBottom: 0,
              }}
            />

            {/* Gold radial glow under feet */}
            <div
              className="absolute bottom-0 left-1/2 -translate-x-1/2 pointer-events-none"
              style={{
                width: "55%",
                height: "60px",
                background: "radial-gradient(ellipse, rgba(200,140,0,0.5) 0%, transparent 70%)",
                zIndex: 1,
              }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
