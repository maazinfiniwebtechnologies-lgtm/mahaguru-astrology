import { motion } from "framer-motion";
import { Lock, Clock, ShieldCheck, HeartHandshake } from "lucide-react";

export function WhyChooseUs() {
  const features = [
    {
      title: "100% Privacy Guarantee",
      description: "Your identity and problems remain completely confidential. We never share client details.",
      icon: Lock
    },
    {
      title: "24/7 Service Available",
      description: "Problems don't wait for business hours. We are available round the clock for emergencies.",
      icon: Clock
    },
    {
      title: "Accurate Solutions",
      description: "Highly effective remedies with a proven 99% success rate across thousands of cases.",
      icon: ShieldCheck
    },
    {
      title: "Personal Guidance",
      description: "Every individual receives customized attention and unique remedies for their specific chart.",
      icon: HeartHandshake
    }
  ];

  return (
    <section className="py-24">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-serif font-bold text-white mb-6"
          >
            Why Choose <span className="text-primary italic">Us</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-8 rounded-2xl border border-white/5 bg-white/5 hover:bg-primary/5 hover:border-primary/20 transition-all duration-300 group"
              >
                <div className="w-16 h-16 mx-auto bg-background rounded-full border border-primary/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
