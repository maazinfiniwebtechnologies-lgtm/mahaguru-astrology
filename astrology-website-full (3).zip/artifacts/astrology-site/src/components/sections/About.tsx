import { motion } from "framer-motion";

export function About() {
  return (
    <section className="py-24 relative overflow-hidden" id="about">
      {/* Decorative background elements */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-96 h-96 bg-secondary/30 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-t-full rounded-b-lg border-2 border-primary/20 p-2 relative">
              <div className="absolute inset-0 border border-primary/40 rounded-t-full rounded-b-lg m-6 pointer-events-none" />
              <div className="w-full h-full rounded-t-full rounded-b-lg overflow-hidden bg-secondary relative">
                {/* Fallback pattern since we don't have an image generator for the astrologer specifically in the prompt, using styling */}
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1603513492128-ba7bc9b3e143?q=80&w=1000')] bg-cover bg-center opacity-40 mix-blend-overlay" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
                
                {/* Centered content block replacing missing image */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8">
                  <div className="w-24 h-24 rounded-full border-2 border-primary/50 flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(224,170,62,0.3)]">
                    <span className="text-4xl font-serif text-primary font-bold">Om</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-8 -right-8 glass-card p-6 rounded-2xl border border-primary/30 max-w-xs shadow-2xl">
              <h4 className="text-4xl font-serif font-bold text-primary mb-2">35+</h4>
              <p className="text-white font-medium">Years of Spiritual Experience</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6 leading-tight">
              Meet The Master <br />
              <span className="text-primary italic">Astrologer</span>
            </h2>
            
            <div className="space-y-6 text-muted-foreground text-lg leading-relaxed">
              <p>
                With over three decades of profound experience in Vedic Astrology, our Master Astrologer has transformed the lives of thousands of individuals globally. Rooted in ancient spiritual traditions and passed down through generations, his expertise spans across complex life problems.
              </p>
              <p>
                He is widely recognized as a premier Vashikaran Specialist, offering ethical, powerful, and fast-acting solutions for deeply rooted love and marriage problems. When all doors seem closed, his guidance provides a clear, guaranteed path to happiness.
              </p>
              
              <ul className="space-y-4 mt-8">
                {['Mastery in ancient Vedic astrology & horoscope analysis', 'Ethical Vashikaran for love & relationship recovery', 'Powerful rituals for black magic & negative energy removal', '100% confidential, private, and judgment-free consultations'].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-1">
                      <div className="w-2 h-2 rounded-full bg-primary" />
                    </div>
                    <span className="text-white">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
