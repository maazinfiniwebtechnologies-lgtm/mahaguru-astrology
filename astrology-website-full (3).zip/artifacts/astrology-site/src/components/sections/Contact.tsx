import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export function Contact() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [service, setService] = useState("");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const form = e.currentTarget;
    const data = {
      name: (form.querySelector("[name=name]") as HTMLInputElement).value,
      phone: (form.querySelector("[name=phone]") as HTMLInputElement).value,
      email: (form.querySelector("[name=email]") as HTMLInputElement)?.value || undefined,
      service: service || undefined,
      message: (form.querySelector("[name=message]") as HTMLTextAreaElement).value,
    };

    try {
      const res = await fetch(`${BASE}/api/inquiries`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Server error");
      toast({
        title: "संदेश भेजा गया ✅",
        description: "गुरुजी आपकी समस्या देखेंगे और हमारी टीम जल्द संपर्क करेगी।",
      });
      form.reset();
      setService("");
    } catch {
      toast({
        title: "Error",
        description: "Something went wrong. Please call us directly.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-24 bg-background relative overflow-hidden" id="contact">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-secondary/20 skew-x-12 translate-x-32" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col justify-center"
          >
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
              Get Your <span className="text-primary italic">Solution</span> Today
            </h2>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              Don't suffer in silence. Share your problem with us. Every consultation is 100% confidential and aimed at providing you the fastest possible relief through ancient Vedic wisdom.
            </p>
            
            <div className="glass-card p-8 rounded-2xl border border-primary/20 mt-4">
              <h3 className="text-xl font-bold text-white mb-4">Visit Our Office</h3>
              <p className="text-muted-foreground mb-6">
                Astrology Center, Main Road,<br />
                Gujarat, India 380001
              </p>
              
              <div className="aspect-video w-full rounded-lg bg-secondary flex items-center justify-center border border-primary/20 overflow-hidden relative">
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1000')] bg-cover bg-center opacity-30 mix-blend-overlay" />
                <span className="text-white/50 font-medium z-10 flex flex-col items-center gap-2">
                  <span className="text-2xl">📍</span>
                  Gujarat, India
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <form onSubmit={handleSubmit} className="glass-card p-8 md:p-10 rounded-2xl border border-primary/20">
              <h3 className="text-2xl font-serif font-bold text-white mb-8 text-center">Consultation Form</h3>
              
              <div className="space-y-6">
                <Input
                  required
                  name="name"
                  placeholder="Your Name"
                  className="bg-background/50 border-primary/20 focus-visible:ring-primary text-white h-12"
                  data-testid="input-contact-name"
                />
                
                <Input
                  required
                  name="phone"
                  type="tel"
                  placeholder="Phone / WhatsApp Number"
                  className="bg-background/50 border-primary/20 focus-visible:ring-primary text-white h-12"
                  data-testid="input-contact-phone"
                />

                <Input
                  name="email"
                  type="email"
                  placeholder="Email (optional)"
                  className="bg-background/50 border-primary/20 focus-visible:ring-primary text-white h-12"
                  data-testid="input-contact-email"
                />
                
                <Select value={service} onValueChange={setService}>
                  <SelectTrigger className="bg-background/50 border-primary/20 focus:ring-primary text-white h-12" data-testid="select-contact-problem">
                    <SelectValue placeholder="Select Problem Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="love">Love Problem</SelectItem>
                    <SelectItem value="marriage">Marriage / Divorce</SelectItem>
                    <SelectItem value="vashikaran">Vashikaran Services</SelectItem>
                    <SelectItem value="career">Career / Business</SelectItem>
                    <SelectItem value="blackmagic">Black Magic Removal</SelectItem>
                    <SelectItem value="other">Other Issues</SelectItem>
                  </SelectContent>
                </Select>
                
                <Textarea
                  required
                  name="message"
                  placeholder="Briefly describe your problem..."
                  className="bg-background/50 border-primary/20 focus-visible:ring-primary text-white min-h-[120px] resize-none"
                  data-testid="input-contact-message"
                />
                
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full h-14 text-lg font-bold bg-primary hover:bg-primary/90 text-primary-foreground"
                  data-testid="button-contact-submit"
                >
                  {isSubmitting ? "Sending..." : "Submit for Consultation"}
                </Button>
                
                <p className="text-center text-xs text-muted-foreground mt-4">
                  🔒 100% Privacy Guaranteed. Your information is safe.
                </p>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
