import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const FALLBACK = [
  { id: 0, icon: "❤️", title: "Love Problem Solution", description: "Resolve misunderstandings and reunite with your soulmate through powerful Vedic remedies.", buttonText: "संपर्क करें" },
  { id: 1, icon: "💔", title: "Lost Love Back", description: "Specialized Vashikaran mantras to bring back your ex-partner and reignite the lost spark.", buttonText: "संपर्क करें" },
  { id: 2, icon: "💍", title: "Stop Divorce", description: "Save your marriage from breaking apart with profound astrological interventions.", buttonText: "संपर्क करें" },
  { id: 3, icon: "👫", title: "Husband Wife Problem", description: "Harmonize your marital life and build a strong, peaceful relationship with your spouse.", buttonText: "संपर्क करें" },
  { id: 4, icon: "💼", title: "Business Problem", description: "Overcome financial losses and attract success, wealth, and growth to your business.", buttonText: "संपर्क करें" },
  { id: 5, icon: "📈", title: "Career Problem", description: "Find the right path, clear obstacles, and achieve the professional success you deserve.", buttonText: "संपर्क करें" },
  { id: 6, icon: "🔮", title: "Vashikaran Specialist", description: "Ethical and powerful Vashikaran to gain control over difficult life situations.", buttonText: "संपर्क करें" },
  { id: 7, icon: "🛡️", title: "Black Magic Removal", description: "Identify and eliminate dark energies, evil eyes, and curses protecting your aura.", buttonText: "संपर्क करें" },
  { id: 8, icon: "🏠", title: "Family Problems", description: "Restore peace, resolve property disputes, and end conflicts within the family.", buttonText: "संपर्क करें" },
  { id: 9, icon: "💊", title: "Health Problems", description: "Astrological diagnosis and remedies for chronic issues and unexplained ailments.", buttonText: "संपर्क करें" },
];

interface ServiceItem { id: number; icon: string; title: string; description: string; buttonText: string; }

export function Services() {
  const [items, setItems] = useState<ServiceItem[]>(FALLBACK);

  useEffect(() => {
    fetch(`${BASE}/api/services`)
      .then(r => r.ok ? r.json() : null)
      .then((data: ServiceItem[] | null) => { if (data && data.length > 0) setItems(data); })
      .catch(() => {});
  }, []);

  return (
    <section className="py-24 bg-background relative" id="services">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="text-3xl md:text-5xl font-serif font-bold text-white mb-6"
          >
            Divine <span className="text-primary italic">Solutions</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ delay: 0.1 }} className="text-muted-foreground text-lg"
          >
            Explore our specialized astrological and Vashikaran services tailored to bring peace, prosperity, and love back into your life.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {items.map((service, index) => (
            <motion.div key={service.id}
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }} transition={{ delay: index * 0.05 }}
            >
              <Card className="glass-card h-full p-8 group hover:border-primary/50 transition-all duration-500 hover:-translate-y-2 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors" />
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 border border-primary/20 group-hover:bg-primary/20 transition-colors relative z-10">
                  <span style={{ fontSize: "1.6rem", lineHeight: 1 }}>{service.icon}</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-3 font-serif relative z-10">{service.title}</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed relative z-10">{service.description}</p>
                <Button variant="link" className="text-primary p-0 h-auto hover:text-white font-medium group/btn relative z-10" asChild>
                  <a href="tel:+919849416699">
                    {service.buttonText} <span className="ml-2 group-hover/btn:translate-x-1 transition-transform">→</span>
                  </a>
                </Button>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
