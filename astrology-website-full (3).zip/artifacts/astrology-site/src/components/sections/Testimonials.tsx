import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Card } from "@/components/ui/card";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const FALLBACK = [
  { id: 0, clientName: "Anjali S., Mumbai", review: "I was on the verge of divorce. The vashikaran remedies provided here completely changed my husband's attitude. We are happily living together now. Forever grateful!", rating: 5, clientImage: null },
  { id: 1, clientName: "Rahul M., Delhi", review: "My business was facing continuous losses. After consulting Guruji and following the astrological remedies, I've seen massive growth in just 3 months.", rating: 5, clientImage: null },
  { id: 2, clientName: "Priya K., Bangalore", review: "Lost the love of my life due to a huge misunderstanding. The powerful mantras worked like magic. He called me back within 48 hours. Thank you!", rating: 5, clientImage: null },
];

interface TestimonialItem { id: number; clientName: string; review: string; rating: number; clientImage?: string | null; }

export function Testimonials() {
  const [items, setItems] = useState<TestimonialItem[]>(FALLBACK);

  useEffect(() => {
    fetch(`${BASE}/api/testimonials`)
      .then(r => r.ok ? r.json() : null)
      .then((data: TestimonialItem[] | null) => { if (data && data.length > 0) setItems(data); })
      .catch(() => {});
  }, []);

  return (
    <section className="py-24 bg-secondary/30 relative">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="text-3xl md:text-5xl font-serif font-bold text-white mb-6"
          >
            Client <span className="text-primary italic">Testimonials</span>
          </motion.h2>
          <p className="text-muted-foreground text-lg">Real stories of lives transformed through our divine guidance.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {items.map((item, index) => (
            <motion.div key={item.id}
              initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }} transition={{ delay: index * 0.1 }}
            >
              <Card className="glass-card p-8 h-full relative">
                <div className="flex text-primary mb-6">
                  {[...Array(Math.max(1, Math.min(5, item.rating)))].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-muted-foreground text-lg italic mb-8 leading-relaxed">"{item.review}"</p>
                <div className="flex items-center gap-4 mt-auto">
                  {item.clientImage ? (
                    <img src={item.clientImage} alt={item.clientName} className="w-12 h-12 rounded-full object-cover" />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold font-serif text-xl">
                      {item.clientName.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h4 className="text-white font-bold">{item.clientName}</h4>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
