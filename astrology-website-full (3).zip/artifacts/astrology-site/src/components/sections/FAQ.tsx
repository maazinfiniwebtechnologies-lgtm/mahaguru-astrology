import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const FALLBACK = [
  { id: 0, question: "Are my details kept confidential?", answer: "Absolutely. We maintain a strict 100% privacy policy. Your name, contact details, and the problems discussed will never be shared with any third party." },
  { id: 1, question: "How long does it take to see results?", answer: "Results vary depending on the severity of the problem and the specific planetary positions. However, many of our clients start experiencing positive changes within 3 to 7 days of performing the prescribed remedies." },
  { id: 2, question: "Is Vashikaran safe?", answer: "Yes, when performed by an expert for positive intentions like saving a marriage or bringing back lost love, ethical Vashikaran is completely safe and has no negative side effects." },
  { id: 3, question: "Can I consult over the phone or WhatsApp?", answer: "Yes, we offer 24/7 consultation over phone calls and WhatsApp. Distance does not affect the accuracy of the readings or the effectiveness of the remedies." },
  { id: 4, question: "What information is needed for a reading?", answer: "Generally, we need your birth date, time, and place. If you don't have exact birth details, we can use other astrological methods like Prashna Kundali or Face Reading." },
];

interface FaqItem { id: number; question: string; answer: string; }

export function FAQ() {
  const [items, setItems] = useState<FaqItem[]>(FALLBACK);

  useEffect(() => {
    fetch(`${BASE}/api/faqs`)
      .then(r => r.ok ? r.json() : null)
      .then((data: FaqItem[] | null) => { if (data && data.length > 0) setItems(data); })
      .catch(() => {});
  }, []);

  return (
    <section className="py-24">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="text-3xl md:text-5xl font-serif font-bold text-white mb-6"
          >
            Frequently Asked <span className="text-primary italic">Questions</span>
          </motion.h2>
        </div>
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <Accordion type="single" collapsible className="w-full space-y-4">
            {items.map((faq, index) => (
              <AccordionItem key={faq.id} value={`item-${index}`}
                className="glass-card px-6 border border-primary/20 rounded-lg overflow-hidden"
              >
                <AccordionTrigger className="text-left text-lg font-medium text-white hover:text-primary transition-colors py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-base leading-relaxed pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}
