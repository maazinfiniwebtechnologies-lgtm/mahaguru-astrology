import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";

const navLinks = [
  { name: "होम", href: "/" },
  { name: "सेवाएं", href: "/services" },
  { name: "परिचय", href: "/about" },
  { name: "समाधान", href: "/" },
  { name: "संपर्क करें", href: "/contact" },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      {/* ── Pink Announcement Bar ──────────────── */}
      <div className="announcement-bar" data-testid="bar-announcement">
        <div className="announcement-inner">
          <span className="announcement-text">
            ᛃ &nbsp;केवल वशीकरण करवाने वाले ही सपर्क करें&nbsp;|&nbsp;24/7 Available — संपर्क: 8949416699
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            ᛃ &nbsp;केवल वशीकरण करवाने वाले ही सपर्क करें&nbsp;|&nbsp;24/7 Available — संपर्क: 8949416699
          </span>
        </div>
      </div>

      {/* ── Main Navbar ────────────────────────── */}
      <header
        className={`fixed left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "glass-nav" : "bg-[#0e0020]/90 backdrop-blur-md"
        }`}
        style={{ top: "36px" }}
        data-testid="navbar"
      >
        <div className="container mx-auto px-4 flex items-center justify-between py-3">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0" data-testid="link-logo">
            <span className="navbar-sun-icon">☀</span>
            <span className="navbar-logo-text">
              महागुरु <span className="text-primary">ज्योतिष</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="navbar-link"
                data-testid={`link-nav-${link.name}`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Right controls */}
          <div className="hidden lg:flex items-center gap-2">
            <a
              href="https://wa.me/919849416699"
              target="_blank"
              rel="noreferrer"
              className="navbar-wa-btn"
              data-testid="button-nav-whatsapp"
            >
              <FaWhatsapp className="w-4 h-4" />
              WHATSAPP
            </a>
            <button className="navbar-lang-btn" data-testid="btn-lang-en">EN</button>
            <button className="navbar-lang-btn active" data-testid="btn-lang-hi">हिंदी</button>
            <button className="navbar-lang-btn" data-testid="btn-lang-gu">ગુjrātī</button>
          </div>

          {/* Mobile menu toggle */}
          <button
            className="lg:hidden text-white p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="lg:hidden glass-nav border-t border-primary/20 px-4 py-4 flex flex-col gap-3">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="text-white text-lg py-2 border-b border-white/10"
                onClick={() => setMobileMenuOpen(false)}
                data-testid={`link-mobile-${link.name}`}
              >
                {link.name}
              </Link>
            ))}
            <a
              href="https://wa.me/919849416699"
              target="_blank"
              rel="noreferrer"
              className="navbar-wa-btn w-full justify-center mt-2"
            >
              <FaWhatsapp className="w-4 h-4" />
              WHATSAPP
            </a>
          </div>
        )}
      </header>

      {/* Push content below top bar + navbar */}
      <div style={{ height: "36px" }} />
    </>
  );
}
