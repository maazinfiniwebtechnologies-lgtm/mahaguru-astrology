import { useState, useEffect } from "react";
import { Phone, MessageCircle, ArrowUp } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";

export function FloatingButtons() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      {/* ── Right-side vertical strip (always visible) ── */}
      <div className="floating-strip" data-testid="floating-strip">
        {/* Chat */}
        <a
          href="sms:+919849416699"
          className="fstrip-btn fstrip-chat"
          title="Chat"
          data-testid="btn-strip-chat"
        >
          <MessageCircle className="w-5 h-5" />
        </a>

        {/* Call (solid pink) */}
        <a
          href="tel:+919849416699"
          className="fstrip-btn fstrip-call"
          title="Call"
          data-testid="btn-strip-call"
        >
          <Phone className="w-5 h-5" />
        </a>

        {/* Call outline */}
        <a
          href="tel:+919849416699"
          className="fstrip-btn fstrip-call-outline"
          title="Call"
          data-testid="btn-strip-call2"
        >
          <Phone className="w-5 h-5" />
        </a>

        {/* WhatsApp (gold/yellow) */}
        <a
          href="https://wa.me/919849416699"
          target="_blank"
          rel="noreferrer"
          className="fstrip-btn fstrip-wa"
          title="WhatsApp"
          data-testid="btn-strip-whatsapp"
        >
          <FaWhatsapp className="w-5 h-5" />
        </a>
      </div>

      {/* ── Scroll to top (appears after scroll) ── */}
      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-50 w-12 h-12 rounded-full bg-primary/20 backdrop-blur border border-primary/40 text-primary flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all shadow-lg"
          data-testid="button-scroll-top"
          title="Scroll to top"
        >
          <ArrowUp size={20} />
        </button>
      )}
    </>
  );
}
