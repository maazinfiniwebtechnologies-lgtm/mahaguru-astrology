import { Link } from "wouter";
import { Sun, Phone, Mail, MapPin } from "lucide-react";
import { FaFacebook, FaInstagram, FaYoutube, FaWhatsapp } from "react-icons/fa";

export function Footer() {
  return (
    <footer className="bg-background border-t border-primary/20 pt-16 pb-8 relative overflow-hidden">
      {/* Decorative element */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 relative z-10">
        <div>
          <Link href="/" className="flex items-center gap-2 mb-6" data-testid="link-footer-logo">
            <Sun className="text-primary w-8 h-8" />
            <span className="font-serif text-2xl font-bold text-white tracking-wider">Astro<span className="text-primary">Guru</span></span>
          </Link>
          <p className="text-muted-foreground leading-relaxed mb-6">
            Master Astrologer & Vashikaran Specialist providing powerful, confidential, and accurate solutions for love, marriage, and life problems.
          </p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-all" data-testid="link-social-facebook">
              <FaFacebook size={20} />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-all" data-testid="link-social-instagram">
              <FaInstagram size={20} />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-all" data-testid="link-social-youtube">
              <FaYoutube size={20} />
            </a>
            <a href="https://wa.me/919849416699" className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-all" data-testid="link-social-whatsapp">
              <FaWhatsapp size={20} />
            </a>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-serif text-white mb-6 border-b border-primary/20 pb-2 inline-block">Quick Links</h3>
          <ul className="space-y-3">
            <li><Link href="/" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2" data-testid="link-footer-home"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Home</Link></li>
            <li><Link href="/about" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2" data-testid="link-footer-about"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> About Us</Link></li>
            <li><Link href="/services" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2" data-testid="link-footer-services"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Our Services</Link></li>
            <li><Link href="/contact" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-2" data-testid="link-footer-contact"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Contact Us</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-xl font-serif text-white mb-6 border-b border-primary/20 pb-2 inline-block">Our Services</h3>
          <ul className="space-y-3">
            <li className="text-muted-foreground flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Love Problem Solution</li>
            <li className="text-muted-foreground flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Vashikaran Specialist</li>
            <li className="text-muted-foreground flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Marriage Problems</li>
            <li className="text-muted-foreground flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-primary" /> Black Magic Removal</li>
          </ul>
        </div>

        <div>
          <h3 className="text-xl font-serif text-white mb-6 border-b border-primary/20 pb-2 inline-block">Contact Info</h3>
          <ul className="space-y-4">
            <li className="flex gap-3">
              <Phone className="text-primary shrink-0 w-5 h-5 mt-1" />
              <div>
                <p className="text-white font-medium">Call Us Now</p>
                <a href="tel:+919849416699" className="text-muted-foreground hover:text-primary">+91 9849416699</a>
              </div>
            </li>
            <li className="flex gap-3">
              <Mail className="text-primary shrink-0 w-5 h-5 mt-1" />
              <div>
                <p className="text-white font-medium">Email Us</p>
                <a href="mailto:info@astroguru.com" className="text-muted-foreground hover:text-primary">info@astroguru.com</a>
              </div>
            </li>
            <li className="flex gap-3">
              <MapPin className="text-primary shrink-0 w-5 h-5 mt-1" />
              <div>
                <p className="text-white font-medium">Visit Office</p>
                <p className="text-muted-foreground">Gujarat, India</p>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <div className="container mx-auto px-4 mt-12 pt-8 border-t border-primary/10 text-center text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} AstroGuru Premium Jyotish Services. All Rights Reserved.</p>
        <p className="mt-2 text-primary/60">Designed by InfiniWeb Technologies</p>
      </div>
    </footer>
  );
}
