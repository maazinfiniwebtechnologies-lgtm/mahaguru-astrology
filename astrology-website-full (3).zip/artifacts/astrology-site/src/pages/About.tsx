import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingButtons } from "@/components/layout/FloatingButtons";
import { About as AboutSection } from "@/components/sections/About";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-white mb-4">About <span className="text-primary italic">Us</span></h1>
          <p className="text-muted-foreground">Learn more about the master astrologer and our journey.</p>
        </div>
        <AboutSection />
      </main>

      <Footer />
      <FloatingButtons />
    </div>
  );
}
