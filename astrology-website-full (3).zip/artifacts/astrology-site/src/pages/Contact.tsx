import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingButtons } from "@/components/layout/FloatingButtons";
import { Contact as ContactSection } from "@/components/sections/Contact";

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-white mb-4">Contact <span className="text-primary italic">Us</span></h1>
          <p className="text-muted-foreground">Reach out today for a confidential consultation.</p>
        </div>
        <ContactSection />
      </main>

      <Footer />
      <FloatingButtons />
    </div>
  );
}
