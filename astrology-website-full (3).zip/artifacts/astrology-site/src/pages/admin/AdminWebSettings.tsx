import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { ImageUpload, FormCard, Field, inputCls, inputStyle, PageHeader } from "./shared";

const FIELDS = [
  { key: "site_name",    label: "Website Name",     placeholder: "महागुरु ज्योतिष" },
  { key: "phone",        label: "Phone Number",     placeholder: "+91 9849416699" },
  { key: "whatsapp",     label: "WhatsApp Number",  placeholder: "+91 9849416699" },
  { key: "email",        label: "Email",            placeholder: "info@mahagurujyotish.com" },
  { key: "address",      label: "Office Address",   placeholder: "Main Road, Gujarat 380001" },
  { key: "fb_url",       label: "Facebook URL",     placeholder: "https://facebook.com/..." },
  { key: "insta_url",    label: "Instagram URL",    placeholder: "https://instagram.com/..." },
  { key: "yt_url",       label: "YouTube Channel",  placeholder: "https://youtube.com/..." },
];

export default function AdminWebSettings() {
  const token = useAdminAuth();
  const [vals, setVals] = useState<Record<string, string>>({});
  const [logo, setLogo] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!token) return;
    adminFetch("/api/admin/settings").then(r => r.json()).then((d: Record<string,string>) => {
      setVals(d);
      if (d.logo) setLogo(d.logo);
    });
  }, [token]);

  const set = (k: string, v: string) => setVals(p => ({ ...p, [k]: v }));

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const payload = { ...vals };
    if (logo) payload.logo = logo;
    await adminFetch("/api/admin/settings", { method: "PUT", body: JSON.stringify(payload) });
    setSaving(false); setSaved(true); setTimeout(() => setSaved(false), 2000);
  };

  return (
    <AdminLayout>
      <PageHeader title="Website Settings" subtitle="Manage site name, logo, contact info & social links" />
      <div className="max-w-2xl space-y-5">
        <FormCard title="Branding" onSubmit={handleSave} submitting={saving} saved={saved}>
          <ImageUpload label="Site Logo" value={logo} onChange={setLogo} />
          <Field label="Website Name">
            <input className={inputCls} style={inputStyle} placeholder="महागुरु ज्योतिष"
              value={vals.site_name ?? ""} onChange={e => set("site_name", e.target.value)} />
          </Field>
        </FormCard>

        <FormCard title="Contact Information" onSubmit={handleSave} submitting={saving} saved={saved}>
          {FIELDS.filter(f => ["phone","whatsapp","email","address"].includes(f.key)).map(f => (
            <Field key={f.key} label={f.label}>
              <input className={inputCls} style={inputStyle} placeholder={f.placeholder}
                value={vals[f.key] ?? ""} onChange={e => set(f.key, e.target.value)} />
            </Field>
          ))}
        </FormCard>

        <FormCard title="Social Media Links" onSubmit={handleSave} submitting={saving} saved={saved}>
          {FIELDS.filter(f => ["fb_url","insta_url","yt_url"].includes(f.key)).map(f => (
            <Field key={f.key} label={f.label}>
              <input className={inputCls} style={inputStyle} placeholder={f.placeholder}
                value={vals[f.key] ?? ""} onChange={e => set(f.key, e.target.value)} />
            </Field>
          ))}
        </FormCard>
      </div>
    </AdminLayout>
  );
}
