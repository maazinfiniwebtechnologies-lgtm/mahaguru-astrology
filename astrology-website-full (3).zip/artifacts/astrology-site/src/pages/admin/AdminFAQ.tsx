import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { FormCard, Field, inputCls, inputStyle, PageHeader, DataTable, TR, TD } from "./shared";
import { Pencil, Trash2, X, ChevronDown } from "lucide-react";

interface Faq { id: number; question: string; answer: string; displayOrder: number; active: boolean; }
const EMPTY = { question: "", answer: "", displayOrder: 0, active: true };

export default function AdminFAQ() {
  const token = useAdminAuth();
  const [items, setItems] = useState<Faq[]>([]);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState<number | null>(null);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const load = () => adminFetch("/api/admin/faqs").then(r => r.json()).then(setItems);
  useEffect(() => { if (token) load(); }, [token]);

  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));

  const startEdit = (f: Faq) => {
    setEditing(f.id);
    setForm({ question: f.question, answer: f.answer, displayOrder: f.displayOrder, active: f.active });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true);
    if (editing) await adminFetch(`/api/admin/faqs/${editing}`, { method: "PUT", body: JSON.stringify(form) });
    else await adminFetch("/api/admin/faqs", { method: "POST", body: JSON.stringify(form) });
    await load(); setEditing(null); setForm(EMPTY); setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Delete this FAQ?")) return;
    await adminFetch(`/api/admin/faqs/${id}`, { method: "DELETE" });
    await load();
  };

  return (
    <AdminLayout>
      <PageHeader title="FAQ Manager" subtitle="Manage frequently asked questions" />
      <div className="max-w-3xl space-y-5">
        <FormCard title={editing ? "Edit FAQ" : "Add FAQ"} onSubmit={submit} submitting={saving}>
          <Field label="Question">
            <input required className={inputCls} style={inputStyle} placeholder="Is Vashikaran safe?"
              value={form.question} onChange={e => set("question", e.target.value)} />
          </Field>
          <Field label="Answer">
            <textarea required className={inputCls} style={{ ...inputStyle, resize: "vertical" }} rows={3}
              placeholder="Yes, when performed by an expert..."
              value={form.answer} onChange={e => set("answer", e.target.value)} />
          </Field>
          <div className="flex items-center gap-4">
            <Field label="Display Order">
              <input type="number" className={inputCls} style={{ ...inputStyle, width: "80px" }}
                value={form.displayOrder} onChange={e => set("displayOrder", Number(e.target.value))} />
            </Field>
            <label className="flex items-center gap-2 cursor-pointer text-sm text-white/70 mt-5">
              <input type="checkbox" checked={form.active} onChange={e => set("active", e.target.checked)} className="accent-purple-500" />
              Show on website
            </label>
          </div>
          {editing && <button type="button" onClick={() => { setEditing(null); setForm(EMPTY); }} className="flex items-center gap-1 text-sm text-white/40"><X size={14}/> Cancel</button>}
        </FormCard>

        {/* FAQ accordion preview */}
        <div className="space-y-2">
          {items.map(faq => (
            <div key={faq.id} className="rounded-xl border overflow-hidden" style={{ background: "rgba(26,0,53,0.6)", borderColor: "rgba(160,80,255,0.18)" }}>
              <div className="flex items-center gap-3 px-4 py-3 cursor-pointer" onClick={() => setExpanded(expanded === faq.id ? null : faq.id)}>
                <ChevronDown size={16} className={`text-yellow-400 transition-transform ${expanded === faq.id ? "rotate-180" : ""}`} />
                <span className="flex-1 text-white text-sm font-medium">{faq.question}</span>
                <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: faq.active ? "rgba(22,163,74,0.2)" : "rgba(107,114,128,0.2)", color: faq.active ? "#4ade80" : "#9ca3af" }}>
                  {faq.active ? "Active" : "Hidden"}
                </span>
                <button onClick={e => { e.stopPropagation(); startEdit(faq); }} className="text-yellow-400 hover:text-yellow-300 ml-1"><Pencil size={14}/></button>
                <button onClick={e => { e.stopPropagation(); del(faq.id); }} className="text-red-400 hover:text-red-300"><Trash2 size={14}/></button>
              </div>
              {expanded === faq.id && (
                <div className="px-4 pb-4 text-sm text-white/60 leading-relaxed border-t" style={{ borderColor: "rgba(160,80,255,0.1)" }}>
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
          {items.length === 0 && <p className="text-center text-sm py-8" style={{ color: "rgba(255,255,255,0.3)" }}>No FAQs yet</p>}
        </div>
      </div>
    </AdminLayout>
  );
}
