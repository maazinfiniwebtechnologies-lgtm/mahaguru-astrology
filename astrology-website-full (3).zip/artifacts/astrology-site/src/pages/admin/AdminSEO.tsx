import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { FormCard, Field, inputCls, inputStyle, PageHeader, T } from "./shared";

export default function AdminSEO() {
  const token = useAdminAuth();
  const [vals, setVals] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!token) return;
    adminFetch("/api/admin/settings").then(r => r.json()).then(setVals);
  }, [token]);

  const set = (k: string, v: string) => setVals(p => ({ ...p, [k]: v }));

  const save = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true);
    await adminFetch("/api/admin/settings", { method: "PUT", body: JSON.stringify(vals) });
    setSaving(false); setSaved(true); setTimeout(() => setSaved(false), 2000);
  };

  const title = vals.seo_title ?? "";
  const desc = vals.seo_description ?? "";

  return (
    <AdminLayout>
      <PageHeader title="SEO Settings" subtitle="Control how the website appears in search engines" />
      <div className="max-w-2xl space-y-5">
        <FormCard title="Search Engine Optimization" onSubmit={save} submitting={saving} saved={saved}>
          <Field label="Meta Title">
            <input className={inputCls} style={inputStyle}
              placeholder="महागुरु ज्योतिष — प्रीमियम ज्योतिषी | Vashikaran Expert"
              value={vals.seo_title ?? ""} onChange={e => set("seo_title", e.target.value)} />
            <p className="text-xs mt-1" style={{ color: title.length > 60 ? "#f87171" : T.muted }}>
              {title.length}/60 characters {title.length > 60 && "— too long!"}
            </p>
          </Field>
          <Field label="Meta Description">
            <textarea className={inputCls} style={{ ...inputStyle, resize: "vertical" }} rows={3}
              placeholder="Best astrologer in India. Expert in vashikaran, love problem solution, black magic removal..."
              value={vals.seo_description ?? ""} onChange={e => set("seo_description", e.target.value)} />
            <p className="text-xs mt-1" style={{ color: desc.length > 160 ? "#f87171" : T.muted }}>
              {desc.length}/160 characters {desc.length > 160 && "— too long!"}
            </p>
          </Field>
          <Field label="Keywords (comma separated)">
            <input className={inputCls} style={inputStyle}
              placeholder="vashikaran specialist, love problem solution, astrologer Gujarat"
              value={vals.seo_keywords ?? ""} onChange={e => set("seo_keywords", e.target.value)} />
          </Field>
          <Field label="OG / Social Share Image URL">
            <input className={inputCls} style={inputStyle}
              placeholder="https://yoursite.com/og-image.jpg"
              value={vals.og_image ?? ""} onChange={e => set("og_image", e.target.value)} />
          </Field>
        </FormCard>

        {/* SERP preview */}
        {(title || desc) && (
          <div className="rounded-2xl border p-5" style={{ background: T.card, borderColor: T.border }}>
            <p className="text-xs font-semibold mb-3" style={{ color: T.muted }}>Google Preview</p>
            <div className="bg-white rounded-lg p-4">
              <div className="text-green-700 text-xs mb-1">mahagurujyotish.com</div>
              <div className="text-blue-700 text-lg font-medium leading-tight mb-1 truncate">{title || "Page Title"}</div>
              <div className="text-gray-600 text-sm leading-snug line-clamp-2">{desc || "Page description will appear here..."}</div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
