import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { FormCard, Field, inputCls, inputStyle, PageHeader, DataTable, TR, TD, GoldButton } from "./shared";
import { Pencil, Trash2, Plus, X } from "lucide-react";

interface Service {
  id: number; title: string; description: string;
  icon: string; buttonText: string; displayOrder: number; active: boolean;
}

const EMPTY: Omit<Service, "id"> = { title: "", description: "", icon: "⭐", buttonText: "संपर्क करें", displayOrder: 0, active: true };

export default function AdminServices() {
  const token = useAdminAuth();
  const [items, setItems] = useState<Service[]>([]);
  const [form, setForm] = useState<Omit<Service,"id">>(EMPTY);
  const [editing, setEditing] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const load = () => adminFetch("/api/admin/services").then(r => r.json()).then(setItems);
  useEffect(() => { if (token) load(); }, [token]);

  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));

  const startEdit = (svc: Service) => {
    setEditing(svc.id);
    setForm({ title: svc.title, description: svc.description, icon: svc.icon, buttonText: svc.buttonText, displayOrder: svc.displayOrder, active: svc.active });
  };

  const cancelEdit = () => { setEditing(null); setForm(EMPTY); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true);
    if (editing) {
      await adminFetch(`/api/admin/services/${editing}`, { method: "PUT", body: JSON.stringify(form) });
    } else {
      await adminFetch("/api/admin/services", { method: "POST", body: JSON.stringify(form) });
    }
    await load(); setEditing(null); setForm(EMPTY); setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Delete this service?")) return;
    await adminFetch(`/api/admin/services/${id}`, { method: "DELETE" });
    await load();
  };

  return (
    <AdminLayout>
      <PageHeader title="Services Manager" subtitle="Add, edit or remove services shown on the website" />
      <div className="max-w-4xl space-y-5">
        <FormCard title={editing ? "Edit Service" : "Add New Service"} onSubmit={handleSubmit} submitting={saving}>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Service Title">
              <input required className={inputCls} style={inputStyle} placeholder="Love Problem Solution"
                value={form.title} onChange={e => set("title", e.target.value)} />
            </Field>
            <Field label="Icon (emoji or text)">
              <input className={inputCls} style={inputStyle} placeholder="❤️"
                value={form.icon} onChange={e => set("icon", e.target.value)} />
            </Field>
          </div>
          <Field label="Description">
            <textarea className={inputCls} style={{ ...inputStyle, resize: "vertical" }} rows={2}
              placeholder="Brief description of this service..."
              value={form.description} onChange={e => set("description", e.target.value)} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Button Text">
              <input className={inputCls} style={inputStyle} placeholder="संपर्क करें"
                value={form.buttonText} onChange={e => set("buttonText", e.target.value)} />
            </Field>
            <Field label="Display Order">
              <input type="number" className={inputCls} style={inputStyle}
                value={form.displayOrder} onChange={e => set("displayOrder", Number(e.target.value))} />
            </Field>
          </div>
          <label className="flex items-center gap-2 cursor-pointer text-sm text-white/70">
            <input type="checkbox" checked={form.active} onChange={e => set("active", e.target.checked)} className="accent-purple-500" />
            Show on website
          </label>
          {editing && (
            <button type="button" onClick={cancelEdit} className="flex items-center gap-1 text-sm text-white/40 hover:text-white">
              <X size={14} /> Cancel Edit
            </button>
          )}
        </FormCard>

        <DataTable headers={["Icon", "Title", "Description", "Order", "Active", "Actions"]} empty={items.length === 0}>
          {items.map(svc => (
            <TR key={svc.id}>
              <TD><span style={{ fontSize: "1.4rem" }}>{svc.icon}</span></TD>
              <TD><span className="font-medium text-white">{svc.title}</span></TD>
              <TD><span className="text-white/50 text-xs line-clamp-2" style={{ maxWidth: "220px" }}>{svc.description}</span></TD>
              <TD>{svc.displayOrder}</TD>
              <TD>
                <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: svc.active ? "rgba(22,163,74,0.2)" : "rgba(107,114,128,0.2)", color: svc.active ? "#4ade80" : "#9ca3af" }}>
                  {svc.active ? "Active" : "Hidden"}
                </span>
              </TD>
              <TD>
                <div className="flex gap-2">
                  <button onClick={() => startEdit(svc)} className="text-yellow-400 hover:text-yellow-300"><Pencil size={15} /></button>
                  <button onClick={() => del(svc.id)} className="text-red-400 hover:text-red-300"><Trash2 size={15} /></button>
                </div>
              </TD>
            </TR>
          ))}
        </DataTable>
      </div>
    </AdminLayout>
  );
}
