import { useRef, useState } from "react";
import { Upload, X } from "lucide-react";

/* ── Gold/Purple theme tokens ── */
export const T = {
  bg: "#0d0020",
  sidebar: "#110028",
  card: "#1a0035",
  border: "rgba(160,80,255,0.18)",
  gold: "#f6d365",
  pink: "#e91e8c",
  text: "rgba(255,255,255,0.85)",
  muted: "rgba(255,255,255,0.4)",
};

/* ── ImageUpload component ── */
interface ImageUploadProps {
  value?: string;
  onChange: (b64: string | "") => void;
  label?: string;
}

export function ImageUpload({ value, onChange, label = "Upload Image" }: ImageUploadProps) {
  const ref = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) { alert("Max image size is 3 MB"); return; }
    const reader = new FileReader();
    reader.onload = () => onChange(reader.result as string);
    reader.readAsDataURL(file);
  };

  return (
    <div>
      {label && <label className="block text-xs mb-1.5" style={{ color: T.muted }}>{label}</label>}
      <div
        className="relative rounded-xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer overflow-hidden"
        style={{ borderColor: "rgba(246,211,101,0.3)", minHeight: "110px", background: "rgba(246,211,101,0.03)" }}
        onClick={() => ref.current?.click()}
      >
        {value ? (
          <>
            <img src={value} alt="preview" className="w-full h-32 object-contain" />
            <button
              type="button"
              onClick={e => { e.stopPropagation(); onChange(""); }}
              className="absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center"
              style={{ background: "rgba(0,0,0,0.6)" }}
            >
              <X size={14} color="#fff" />
            </button>
          </>
        ) : (
          <div className="flex flex-col items-center gap-2 py-4">
            <Upload size={22} style={{ color: T.gold, opacity: 0.7 }} />
            <span className="text-xs" style={{ color: T.muted }}>Click to upload (max 3MB)</span>
          </div>
        )}
        <input ref={ref} type="file" accept="image/*" className="hidden" onChange={handleFile} />
      </div>
    </div>
  );
}

/* ── FormCard wrapper ── */
export function FormCard({ title, children, onSubmit, submitting, saved }: {
  title: string;
  children: React.ReactNode;
  onSubmit: (e: React.FormEvent) => void;
  submitting?: boolean;
  saved?: boolean;
}) {
  return (
    <form onSubmit={onSubmit} className="rounded-2xl border p-6 space-y-5" style={{ background: T.card, borderColor: T.border }}>
      <h3 className="font-semibold text-white text-base">{title}</h3>
      {children}
      <GoldButton type="submit" disabled={submitting}>
        {saved ? "✓ Saved" : submitting ? "Saving…" : "Save Changes"}
      </GoldButton>
    </form>
  );
}

/* ── Shared input / textarea styles ── */
export const inputCls = `w-full px-3 py-2.5 rounded-lg text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-purple-500 border`;
export const inputStyle = { background: "rgba(255,255,255,0.04)", borderColor: "rgba(160,80,255,0.25)" };

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs mb-1.5" style={{ color: T.muted }}>{label}</label>
      {children}
    </div>
  );
}

/* ── Gold button ── */
export function GoldButton({ children, type = "button", onClick, disabled, danger }: {
  children: React.ReactNode;
  type?: "button" | "submit";
  onClick?: () => void;
  disabled?: boolean;
  danger?: boolean;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
      style={{ background: danger ? "#be123c" : `linear-gradient(90deg, ${T.pink}, #9c1170)` }}
    >
      {children}
    </button>
  );
}

/* ── Star rating display ── */
export function Stars({ n }: { n: number }) {
  return <span>{Array.from({ length: 5 }, (_, i) => <span key={i} style={{ color: i < n ? T.gold : "#333" }}>★</span>)}</span>;
}

/* ── Section page wrapper ── */
export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-bold text-white">{title}</h1>
      {subtitle && <p className="text-sm mt-0.5" style={{ color: T.muted }}>{subtitle}</p>}
    </div>
  );
}

/* ── Table container ── */
export function DataTable({ headers, children, empty }: {
  headers: string[];
  children: React.ReactNode;
  empty?: boolean;
}) {
  return (
    <div className="rounded-2xl border overflow-hidden" style={{ background: T.card, borderColor: T.border }}>
      {empty ? (
        <div className="py-16 text-center text-sm" style={{ color: T.muted }}>No items yet. Add one above.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: `1px solid ${T.border}` }}>
                {headers.map(h => (
                  <th key={h} className="text-left px-5 py-3 font-medium" style={{ color: T.muted }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>{children}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function TR({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <tr
      onClick={onClick}
      className="border-b transition-colors"
      style={{ borderColor: "rgba(160,80,255,0.08)", cursor: onClick ? "pointer" : undefined }}
    >
      {children}
    </tr>
  );
}

export function TD({ children }: { children: React.ReactNode }) {
  return <td className="px-5 py-3 text-white/80">{children}</td>;
}
