import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { FormCard, Field, inputCls, inputStyle, PageHeader, DataTable, TR, TD, GoldButton, ImageUpload, Stars } from "./shared";
import { Pencil, Trash2, X } from "lucide-react";

interface Testimonial {
  id: number; clientName: string; review: string;
  rating: number; clientImage?: string; displayOrder: number; active: boolean;
}

const EMPTY = { clientName: "", review: "", rating: 5, clientImage: "", displayOrder: 0, active: true };

export default function AdminTestimonials() {
  const token = useAdminAuth();
  const [items, setItems] = useState<Testimonial[]>([]);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const load = () => adminFetch("/api/admin/testimonials").then(r => r.json()).then(setItems);
  useEffect(() => { if (token) load(); }, [token]);

  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));

  const startEdit = (t: Testimonial) => {
    setEditing(t.id);
    setForm({ clientName: t.clientName, review: t.review, rating: t.rating, clientImage: t.clientImage ?? "", displayOrder: t.displayOrder, active: t.active });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true);
    const payload = { ...form, clientImage: form.clientImage || null };
    if (editing) await adminFetch(`/api/admin/testimonials/${editing}`, { method: "PUT", body: JSON.stringify(payload) });
    else await adminFetch("/api/admin/testimonials", { method: "POST", body: JSON.stringify(payload) });
    await load(); setEditing(null); setForm(EMPTY); setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Delete?")) return;
    await adminFetch(`/api/admin/testimonials/${id}`, { method: "DELETE" });
    await load();
  };

  return (
    <AdminLayout>
      <PageHeader title="Testimonials Manager" subtitle="Manage client reviews shown on the website" />
      <div className="max-w-4xl space-y-5">
        <FormCard title={editing ? "Edit Testimonial" : "Add Testimonial"} onSubmit={submit} submitting={saving}>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Client Name">
              <input required className={inputCls} style={inputStyle} placeholder="Anjali S., Mumbai"
                value={form.clientName} onChange={e => set("clientName", e.target.value)} />
            </Field>
            <Field label="Rating (1-5)">
              <input type="number" min={1} max={5} className={inputCls} style={inputStyle}
                value={form.rating} onChange={e => set("rating", Number(e.target.value))} />
            </Field>
          </div>
          <Field label="Review">
            <textarea required className={inputCls} style={{ ...inputStyle, resize: "vertical" }} rows={3}
              placeholder="Client review text..."
              value={form.review} onChange={e => set("review", e.target.value)} />
          </Field>
          <ImageUpload label="Client Photo (optional)" value={form.clientImage} onChange={v => set("clientImage", v)} />
          <div className="flex items-center gap-4">
            <Field label="Display Order">
              <input type="number" className={inputCls} style={{ ...inputStyle, width: "80px" }}
                value={form.displayOrder} onChange={e => set("displayOrder", Number(e.target.value))} />
            </Field>
            <label className="flex items-center gap-2 cursor-pointer text-sm text-white/70 mt-5">
              <input type="checkbox" checked={form.active} onChange={e => set("active", e.target.checked)} className="accent-purple-500" />
              Show on website
            </label>
          </div>
          {editing && <button type="button" onClick={() => { setEditing(null); setForm(EMPTY); }} className="flex items-center gap-1 text-sm text-white/40 hover:text-white"><X size={14} /> Cancel</button>}
        </FormCard>

        <DataTable headers={["Photo", "Name", "Review", "Rating", "Status", "Actions"]} empty={items.length === 0}>
          {items.map(t => (
            <TR key={t.id}>
              <TD>
                {t.clientImage
                  ? <img src={t.clientImage} alt={t.clientName} className="w-9 h-9 rounded-full object-cover" />
                  : <div className="w-9 h-9 rounded-full bg-purple-900 flex items-center justify-center text-white text-sm font-bold">{t.clientName[0]}</div>
                }
              </TD>
              <TD><span className="font-medium text-white">{t.clientName}</span></TD>
              <TD><span className="text-white/50 text-xs line-clamp-2" style={{ maxWidth: "200px" }}>{t.review}</span></TD>
              <TD><Stars n={t.rating} /></TD>
              <TD>
                <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: t.active ? "rgba(22,163,74,0.2)" : "rgba(107,114,128,0.2)", color: t.active ? "#4ade80" : "#9ca3af" }}>
                  {t.active ? "Active" : "Hidden"}
                </span>
              </TD>
              <TD>
                <div className="flex gap-2">
                  <button onClick={() => startEdit(t)} className="text-yellow-400 hover:text-yellow-300"><Pencil size={15} /></button>
                  <button onClick={() => del(t.id)} className="text-red-400 hover:text-red-300"><Trash2 size={15} /></button>
                </div>
              </TD>
            </TR>
          ))}
        </DataTable>
      </div>
    </AdminLayout>
  );
}
