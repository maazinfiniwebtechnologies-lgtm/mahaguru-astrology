import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { Save } from "lucide-react";

const FIELDS = [
  { key: "phone", label: "Phone Number", placeholder: "+91 9849416699" },
  { key: "whatsapp", label: "WhatsApp Number", placeholder: "+91 9849416699" },
  { key: "address", label: "Office Address", placeholder: "Main Road, Gujarat, India 380001" },
  { key: "email", label: "Contact Email", placeholder: "info@mahagurujyotish.com" },
];

export default function AdminSettings() {
  const token = useAdminAuth();
  const [values, setValues] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    adminFetch("/api/admin/settings")
      .then(r => r.json())
      .then(setValues)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await adminFetch("/api/admin/settings", {
      method: "PUT",
      body: JSON.stringify(values),
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <AdminLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
          <p className="text-white/40 text-sm mt-0.5">Update site contact details</p>
        </div>

        <form
          onSubmit={handleSave}
          className="rounded-xl border border-primary/10 p-7 space-y-5"
          style={{ background: "#1a0035" }}
        >
          {loading ? (
            <p className="text-white/40 text-center py-8">Loading…</p>
          ) : (
            FIELDS.map(field => (
              <div key={field.key}>
                <label className="block text-sm text-white/60 mb-2">{field.label}</label>
                <input
                  type="text"
                  value={values[field.key] ?? ""}
                  onChange={e => setValues(v => ({ ...v, [field.key]: e.target.value }))}
                  placeholder={field.placeholder}
                  className="w-full h-11 px-4 rounded-lg bg-white/5 border border-primary/20 text-white placeholder:text-white/25 focus:outline-none focus:border-primary"
                  data-testid={`input-setting-${field.key}`}
                />
              </div>
            ))
          )}

          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-lg text-white font-semibold text-sm transition-opacity hover:opacity-90"
            style={{ background: "linear-gradient(90deg, #e91e8c, #c2185b)" }}
            data-testid="button-save-settings"
          >
            <Save size={16} />
            {saved ? "Saved ✓" : "Save Settings"}
          </button>
        </form>

        <div className="rounded-xl border border-red-500/20 p-5" style={{ background: "#1a0035" }}>
          <h3 className="text-red-400 font-semibold mb-1 text-sm">Admin Password</h3>
          <p className="text-white/40 text-xs">
            To change the admin password, set the <code className="text-primary bg-primary/10 px-1 rounded">ADMIN_PASSWORD</code> environment variable on the API server.
          </p>
        </div>
      </div>
    </AdminLayout>
  );
}
