import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { Trash2, Phone, MessageSquare } from "lucide-react";

interface Inquiry {
  id: number; name: string; phone: string; email?: string; service?: string;
  message: string; status: string; createdAt: string;
}

const STATUSES = ["new", "contacted", "resolved", "spam"];
const STATUS_COLORS: Record<string, string> = {
  new: "#e91e8c", contacted: "#7c3aed", resolved: "#16a34a", spam: "#6b7280",
};

export default function AdminInquiries() {
  const token = useAdminAuth();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Inquiry | null>(null);

  useEffect(() => {
    if (!token) return;
    setLoading(true);
    adminFetch("/api/admin/inquiries")
      .then(r => r.json())
      .then(setInquiries)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token]);

  const updateStatus = async (id: number, status: string) => {
    await adminFetch(`/api/admin/inquiries/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ status }),
    });
    setInquiries(prev => prev.map(i => i.id === id ? { ...i, status } : i));
    if (selected?.id === id) setSelected(prev => prev ? { ...prev, status } : null);
  };

  const deleteInq = async (id: number) => {
    if (!confirm("Delete this inquiry?")) return;
    await adminFetch(`/api/admin/inquiries/${id}`, { method: "DELETE" });
    setInquiries(prev => prev.filter(i => i.id !== id));
    if (selected?.id === id) setSelected(null);
  };

  const filtered = filter === "all" ? inquiries : inquiries.filter(i => i.status === filter);

  return (
    <AdminLayout>
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white">Inquiries</h1>
            <p className="text-white/40 text-sm mt-0.5">{inquiries.length} total</p>
          </div>

          {/* Filter pills */}
          <div className="flex gap-2 flex-wrap">
            {["all", ...STATUSES].map(s => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all"
                style={{
                  background: filter === s ? (STATUS_COLORS[s] ?? "#e91e8c") : "rgba(255,255,255,0.05)",
                  color: "#fff",
                }}
                data-testid={`filter-${s}`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-5">
          {/* Table */}
          <div className="flex-1 rounded-xl border border-primary/10 overflow-hidden" style={{ background: "#1a0035" }}>
            {loading ? (
              <div className="py-16 text-center text-white/30">Loading…</div>
            ) : filtered.length === 0 ? (
              <div className="py-16 text-center text-white/30">
                <MessageSquare className="mx-auto mb-3 opacity-30" size={32} />
                <p>No inquiries found</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-primary/10">
                      <th className="text-left px-5 py-3 text-white/40 font-medium">Name</th>
                      <th className="text-left px-5 py-3 text-white/40 font-medium hidden sm:table-cell">Phone</th>
                      <th className="text-left px-5 py-3 text-white/40 font-medium hidden md:table-cell">Service</th>
                      <th className="text-left px-5 py-3 text-white/40 font-medium">Status</th>
                      <th className="text-left px-5 py-3 text-white/40 font-medium hidden lg:table-cell">Date</th>
                      <th className="px-5 py-3" />
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((inq) => (
                      <tr
                        key={inq.id}
                        className="border-b border-primary/5 hover:bg-white/3 cursor-pointer transition-colors"
                        style={{ background: selected?.id === inq.id ? "rgba(255,255,255,0.04)" : undefined }}
                        onClick={() => setSelected(inq)}
                        data-testid={`row-inquiry-${inq.id}`}
                      >
                        <td className="px-5 py-3 text-white font-medium">{inq.name}</td>
                        <td className="px-5 py-3 text-white/70 hidden sm:table-cell">{inq.phone}</td>
                        <td className="px-5 py-3 text-white/50 capitalize hidden md:table-cell">{inq.service ?? "—"}</td>
                        <td className="px-5 py-3">
                          <select
                            value={inq.status}
                            onClick={e => e.stopPropagation()}
                            onChange={e => updateStatus(inq.id, e.target.value)}
                            className="rounded px-2 py-1 text-xs font-semibold text-white border-0 cursor-pointer"
                            style={{ background: STATUS_COLORS[inq.status] ?? "#555" }}
                            data-testid={`status-select-${inq.id}`}
                          >
                            {STATUSES.map(s => <option key={s} value={s} className="bg-gray-900 capitalize">{s}</option>)}
                          </select>
                        </td>
                        <td className="px-5 py-3 text-white/40 text-xs hidden lg:table-cell">
                          {new Date(inq.createdAt).toLocaleDateString("en-IN")}
                        </td>
                        <td className="px-5 py-3">
                          <button
                            onClick={e => { e.stopPropagation(); deleteInq(inq.id); }}
                            className="text-red-400/60 hover:text-red-400 transition-colors"
                            data-testid={`btn-delete-${inq.id}`}
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Detail panel */}
          {selected && (
            <div
              className="w-72 shrink-0 rounded-xl border border-primary/10 p-5 space-y-4 hidden md:block"
              style={{ background: "#1a0035" }}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-white font-semibold">Inquiry #{selected.id}</h3>
                <button onClick={() => setSelected(null)} className="text-white/40 hover:text-white text-lg leading-none">×</button>
              </div>

              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-white/40 text-xs mb-0.5">Name</p>
                  <p className="text-white font-medium">{selected.name}</p>
                </div>
                <div>
                  <p className="text-white/40 text-xs mb-0.5">Phone</p>
                  <a href={`tel:${selected.phone}`} className="text-primary flex items-center gap-1.5 hover:underline">
                    <Phone size={14} /> {selected.phone}
                  </a>
                </div>
                {selected.email && (
                  <div>
                    <p className="text-white/40 text-xs mb-0.5">Email</p>
                    <p className="text-white/80">{selected.email}</p>
                  </div>
                )}
                <div>
                  <p className="text-white/40 text-xs mb-0.5">Service</p>
                  <p className="text-white/80 capitalize">{selected.service ?? "Not specified"}</p>
                </div>
                <div>
                  <p className="text-white/40 text-xs mb-0.5">Message</p>
                  <p className="text-white/80 leading-relaxed">{selected.message}</p>
                </div>
                <div>
                  <p className="text-white/40 text-xs mb-0.5">Received</p>
                  <p className="text-white/60 text-xs">{new Date(selected.createdAt).toLocaleString("en-IN")}</p>
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <a
                  href={`https://wa.me/${selected.phone.replace(/\D/g, "")}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 text-center py-2 rounded-lg text-xs font-semibold text-white"
                  style={{ background: "#128c7e" }}
                >
                  WhatsApp
                </a>
                <a
                  href={`tel:${selected.phone}`}
                  className="flex-1 text-center py-2 rounded-lg text-xs font-semibold text-white"
                  style={{ background: "#e91e8c" }}
                >
                  Call
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
