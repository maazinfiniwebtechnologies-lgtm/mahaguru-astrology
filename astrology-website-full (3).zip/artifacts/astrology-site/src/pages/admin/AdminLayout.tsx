import { useEffect, useState } from "react";
import { useLocation, Link } from "wouter";
import {
  LayoutDashboard, Settings, Layout, Package, Image,
  Star, HelpCircle, Play, Inbox, Search, LogOut, Menu, X
} from "lucide-react";
import { T } from "./shared";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export function useAdminAuth() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (!localStorage.getItem("admin_token")) setLocation("/admin/login");
  }, [setLocation]);
  return localStorage.getItem("admin_token") ?? "";
}

export function adminFetch(url: string, options: RequestInit = {}) {
  const token = localStorage.getItem("admin_token") ?? "";
  return fetch(`${BASE}${url}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "x-admin-token": token,
      ...(options.headers ?? {}),
    },
  });
}

const NAV = [
  { href: "/admin/dashboard",    icon: LayoutDashboard, label: "Dashboard" },
  { href: "/admin/web-settings", icon: Settings,         label: "Website Settings" },
  { href: "/admin/homepage",     icon: Layout,           label: "Homepage Editor" },
  { href: "/admin/services",     icon: Package,          label: "Services" },
  { href: "/admin/gallery",      icon: Image,            label: "Gallery" },
  { href: "/admin/testimonials", icon: Star,             label: "Testimonials" },
  { href: "/admin/faqs",         icon: HelpCircle,       label: "FAQs" },
  { href: "/admin/videos",       icon: Play,             label: "Video Reviews" },
  { href: "/admin/inquiries",    icon: Inbox,            label: "Inquiries" },
  { href: "/admin/seo",          icon: Search,           label: "SEO Settings" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [loc] = useLocation();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);

  const logout = async () => {
    const token = localStorage.getItem("admin_token");
    if (token) await fetch(`${BASE}/api/admin/logout`, { method: "POST", headers: { "x-admin-token": token } }).catch(() => {});
    localStorage.removeItem("admin_token");
    setLocation("/admin/login");
  };

  const Sidebar = () => (
    <aside
      className="flex flex-col h-full"
      style={{ background: T.sidebar, borderRight: `1px solid ${T.border}`, width: "224px" }}
    >
      {/* Logo */}
      <div className="px-5 py-4 flex items-center gap-2.5" style={{ borderBottom: `1px solid ${T.border}` }}>
        <span style={{ fontSize: "1.5rem", color: T.gold }}>☀</span>
        <div>
          <p className="text-white font-bold text-sm leading-tight">Admin Panel</p>
          <p className="text-xs" style={{ color: T.muted }}>महागुरु ज्योतिष</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-0.5">
        {NAV.map(({ href, icon: Icon, label }) => {
          const active = loc === href || loc.startsWith(href + "/");
          return (
            <Link
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              className="flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-colors"
              style={{
                color: active ? "#fff" : T.muted,
                background: active ? "rgba(246,211,101,0.1)" : "transparent",
                borderLeft: active ? `2px solid ${T.gold}` : "2px solid transparent",
              }}
            >
              <Icon size={16} style={{ color: active ? T.gold : T.muted }} />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="px-2 py-3" style={{ borderTop: `1px solid ${T.border}` }}>
        <button
          onClick={logout}
          className="flex items-center gap-3 px-3 py-2 w-full rounded-xl text-sm font-medium transition-colors text-red-400 hover:bg-red-500/10"
        >
          <LogOut size={16} />
          Logout
        </button>
      </div>
    </aside>
  );

  return (
    <div className="min-h-screen flex" style={{ background: T.bg, color: "#fff" }}>
      {/* Desktop sidebar */}
      <div className="hidden lg:flex flex-col fixed inset-y-0 left-0 z-30" style={{ width: "224px" }}>
        <Sidebar />
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div className="fixed inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <div className="relative z-50 flex flex-col" style={{ width: "224px" }}>
            <Sidebar />
          </div>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 lg:ml-[224px] flex flex-col min-h-screen">
        <header
          className="sticky top-0 z-20 flex items-center gap-3 px-5 py-3"
          style={{ background: T.sidebar, borderBottom: `1px solid ${T.border}` }}
        >
          <button className="lg:hidden text-white/60 hover:text-white" onClick={() => setOpen(true)}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
          <span className="text-sm font-semibold" style={{ color: T.muted }}>
            {NAV.find(n => loc.startsWith(n.href))?.label ?? "Admin Panel"}
          </span>
        </header>
        <main className="flex-1 p-5 md:p-7">{children}</main>
      </div>
    </div>
  );
}
