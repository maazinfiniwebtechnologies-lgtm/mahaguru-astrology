import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { FormCard, Field, inputCls, inputStyle, PageHeader, DataTable, TR, TD } from "./shared";
import { Pencil, Trash2, X, Play } from "lucide-react";

interface VideoReview { id: number; title: string; youtubeUrl: string; displayOrder: number; active: boolean; }
const EMPTY = { title: "", youtubeUrl: "", displayOrder: 0, active: true };

function getYTId(url: string) {
  const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  return match?.[1] ?? null;
}

export default function AdminVideos() {
  const token = useAdminAuth();
  const [items, setItems] = useState<VideoReview[]>([]);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const load = () => adminFetch("/api/admin/video-reviews").then(r => r.json()).then(setItems);
  useEffect(() => { if (token) load(); }, [token]);

  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));

  const startEdit = (v: VideoReview) => {
    setEditing(v.id);
    setForm({ title: v.title, youtubeUrl: v.youtubeUrl, displayOrder: v.displayOrder, active: v.active });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true);
    if (editing) await adminFetch(`/api/admin/video-reviews/${editing}`, { method: "PUT", body: JSON.stringify(form) });
    else await adminFetch("/api/admin/video-reviews", { method: "POST", body: JSON.stringify(form) });
    await load(); setEditing(null); setForm(EMPTY); setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Delete this video?")) return;
    await adminFetch(`/api/admin/video-reviews/${id}`, { method: "DELETE" });
    await load();
  };

  const ytId = getYTId(form.youtubeUrl);

  return (
    <AdminLayout>
      <PageHeader title="Video Reviews" subtitle="Add YouTube video testimonials" />
      <div className="max-w-4xl space-y-5">
        <FormCard title={editing ? "Edit Video" : "Add YouTube Video"} onSubmit={submit} submitting={saving}>
          <Field label="Video Title">
            <input required className={inputCls} style={inputStyle} placeholder="Client Success Story"
              value={form.title} onChange={e => set("title", e.target.value)} />
          </Field>
          <Field label="YouTube URL">
            <input required className={inputCls} style={inputStyle} placeholder="https://youtube.com/watch?v=..."
              value={form.youtubeUrl} onChange={e => set("youtubeUrl", e.target.value)} />
          </Field>
          {ytId && (
            <div className="rounded-xl overflow-hidden" style={{ aspectRatio: "16/9", maxWidth: "320px" }}>
              <img src={`https://img.youtube.com/vi/${ytId}/hqdefault.jpg`} alt="thumbnail" className="w-full h-full object-cover" />
            </div>
          )}
          <div className="flex items-center gap-4">
            <Field label="Order">
              <input type="number" className={inputCls} style={{ ...inputStyle, width: "80px" }}
                value={form.displayOrder} onChange={e => set("displayOrder", Number(e.target.value))} />
            </Field>
            <label className="flex items-center gap-2 cursor-pointer text-sm text-white/70 mt-5">
              <input type="checkbox" checked={form.active} onChange={e => set("active", e.target.checked)} className="accent-purple-500" />
              Show on website
            </label>
          </div>
          {editing && <button type="button" onClick={() => { setEditing(null); setForm(EMPTY); }} className="flex items-center gap-1 text-sm text-white/40"><X size={14}/> Cancel</button>}
        </FormCard>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {items.map(v => {
            const tid = getYTId(v.youtubeUrl);
            return (
              <div key={v.id} className="rounded-2xl border overflow-hidden" style={{ background: "rgba(26,0,53,0.6)", borderColor: "rgba(160,80,255,0.18)" }}>
                <div className="relative" style={{ aspectRatio: "16/9" }}>
                  {tid ? (
                    <img src={`https://img.youtube.com/vi/${tid}/hqdefault.jpg`} alt={v.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-purple-900/40 flex items-center justify-center">
                      <Play size={32} className="text-white/30" />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-10 h-10 rounded-full bg-red-600/90 flex items-center justify-center">
                      <Play size={18} color="#fff" fill="#fff" />
                    </div>
                  </div>
                </div>
                <div className="p-3 flex items-center justify-between gap-2">
                  <span className="text-sm text-white font-medium truncate">{v.title}</span>
                  <div className="flex gap-2 shrink-0">
                    <button onClick={() => startEdit(v)} className="text-yellow-400"><Pencil size={14}/></button>
                    <button onClick={() => del(v.id)} className="text-red-400"><Trash2 size={14}/></button>
                  </div>
                </div>
              </div>
            );
          })}
          {items.length === 0 && <p className="col-span-3 text-center text-sm py-8" style={{ color: "rgba(255,255,255,0.3)" }}>No videos yet</p>}
        </div>
      </div>
    </AdminLayout>
  );
}
