import { useState } from "react";
import { useLocation } from "wouter";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function AdminLogin() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${BASE}/api/admin/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) { setError("Invalid password. Try again."); return; }
      const { token } = await res.json();
      localStorage.setItem("admin_token", token);
      setLocation("/admin/dashboard");
    } catch {
      setError("Connection error. Is the API server running?");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "linear-gradient(135deg, #0d0020 0%, #1a0035 100%)" }}>
      <div className="w-full max-w-md mx-4">
        <div className="text-center mb-8">
          <div className="text-4xl mb-3">☀</div>
          <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          <p className="text-white/50 text-sm mt-1">महागुरु ज्योतिष</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="glass-card p-8 rounded-2xl border border-primary/20 space-y-5"
        >
          <div>
            <label className="block text-sm text-white/70 mb-2">Admin Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoFocus
              placeholder="Enter admin password"
              className="w-full h-11 px-4 rounded-lg bg-white/5 border border-primary/30 text-white placeholder:text-white/30 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              data-testid="input-admin-password"
            />
          </div>

          {error && (
            <p className="text-red-400 text-sm">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full h-11 rounded-lg font-semibold text-white transition-opacity"
            style={{ background: "linear-gradient(90deg, #e91e8c, #c2185b)" }}
            data-testid="button-admin-login"
          >
            {loading ? "Logging in..." : "Login"}
          </button>

          <p className="text-center text-xs text-white/30">
            Default: astroguru@2024
          </p>
        </form>
      </div>
    </div>
  );
}
