import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { ImageUpload, FormCard, Field, inputCls, inputStyle, PageHeader } from "./shared";

export default function AdminHomepage() {
  const token = useAdminAuth();
  const [vals, setVals] = useState<Record<string, string>>({});
  const [heroImg, setHeroImg] = useState("");
  const [zodiacImg, setZodiacImg] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!token) return;
    adminFetch("/api/admin/settings").then(r => r.json()).then((d: Record<string,string>) => {
      setVals(d);
      if (d.hero_image) setHeroImg(d.hero_image);
      if (d.zodiac_image) setZodiacImg(d.zodiac_image);
    });
  }, [token]);

  const set = (k: string, v: string) => setVals(p => ({ ...p, [k]: v }));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const payload = { ...vals };
    if (heroImg) payload.hero_image = heroImg;
    if (zodiacImg) payload.zodiac_image = zodiacImg;
    await adminFetch("/api/admin/settings", { method: "PUT", body: JSON.stringify(payload) });
    setSaving(false); setSaved(true); setTimeout(() => setSaved(false), 2500);
  };

  return (
    <AdminLayout>
      <PageHeader title="Homepage Editor" subtitle="Edit hero section content and images" />
      <div className="max-w-2xl space-y-5">
        <FormCard title="Hero Text" onSubmit={save} submitting={saving} saved={saved}>
          <Field label="Notice Bar Text (announcement ticker)">
            <input className={inputCls} style={inputStyle}
              placeholder="केवल वशीकरण करवाने वाले ही सपर्क करें | 24/7 Available"
              value={vals.notice_text ?? ""} onChange={e => set("notice_text", e.target.value)} />
          </Field>
          <Field label="Hero Main Title">
            <textarea className={inputCls} style={{ ...inputStyle, resize: "vertical" }} rows={2}
              placeholder="केवल वशीकरण करवाने वाले ही संपर्क करे ।"
              value={vals.hero_title ?? ""} onChange={e => set("hero_title", e.target.value)} />
          </Field>
          <Field label="Hero Subtitle (brand name line)">
            <input className={inputCls} style={inputStyle}
              placeholder="महागुरु ज्योतिष"
              value={vals.hero_subtitle ?? ""} onChange={e => set("hero_subtitle", e.target.value)} />
          </Field>
          <Field label="Hero Caption">
            <input className={inputCls} style={inputStyle}
              placeholder="ऑनलाइन एवं ऑफलाइन सेवाएं उपलब्ध हैं"
              value={vals.hero_caption ?? ""} onChange={e => set("hero_caption", e.target.value)} />
          </Field>
          <Field label="Call Button Text">
            <input className={inputCls} style={inputStyle}
              placeholder="अभी कॉल करें"
              value={vals.cta_call ?? ""} onChange={e => set("cta_call", e.target.value)} />
          </Field>
          <Field label="WhatsApp Button Text">
            <input className={inputCls} style={inputStyle}
              placeholder="WHATSAPP पर चैट करें"
              value={vals.cta_whatsapp ?? ""} onChange={e => set("cta_whatsapp", e.target.value)} />
          </Field>
        </FormCard>

        <FormCard title="Hero Images" onSubmit={save} submitting={saving} saved={saved}>
          <div className="grid grid-cols-2 gap-4">
            <ImageUpload label="Pandit Ji / Hero Image" value={heroImg} onChange={setHeroImg} />
            <ImageUpload label="Zodiac Wheel Background" value={zodiacImg} onChange={setZodiacImg} />
          </div>
        </FormCard>
      </div>
    </AdminLayout>
  );
}
