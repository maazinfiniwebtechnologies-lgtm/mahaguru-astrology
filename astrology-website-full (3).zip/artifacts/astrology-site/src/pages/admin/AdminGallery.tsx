import { useEffect, useState } from "react";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { ImageUpload, PageHeader, GoldButton, T } from "./shared";
import { Trash2, Plus } from "lucide-react";

interface GalleryItem { id: number; imageUrl: string; alt: string; displayOrder: number; }

export default function AdminGallery() {
  const token = useAdminAuth();
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [newImg, setNewImg] = useState("");
  const [newAlt, setNewAlt] = useState("");
  const [saving, setSaving] = useState(false);

  const load = () => adminFetch("/api/admin/gallery").then(r => r.json()).then(setItems);
  useEffect(() => { if (token) load(); }, [token]);

  const add = async () => {
    if (!newImg) { alert("Please select an image first"); return; }
    setSaving(true);
    await adminFetch("/api/admin/gallery", {
      method: "POST",
      body: JSON.stringify({ imageUrl: newImg, alt: newAlt, displayOrder: items.length }),
    });
    setNewImg(""); setNewAlt("");
    await load(); setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Delete this image?")) return;
    await adminFetch(`/api/admin/gallery/${id}`, { method: "DELETE" });
    await load();
  };

  return (
    <AdminLayout>
      <PageHeader title="Gallery Manager" subtitle="Upload and manage gallery images" />
      <div className="max-w-4xl space-y-6">
        {/* Upload section */}
        <div className="rounded-2xl border p-5 space-y-4" style={{ background: T.card, borderColor: T.border }}>
          <h3 className="text-white font-semibold">Upload New Image</h3>
          <ImageUpload value={newImg} onChange={setNewImg} />
          <input
            className="w-full px-3 py-2 rounded-lg text-sm text-white placeholder:text-white/25 focus:outline-none border"
            style={{ background: "rgba(255,255,255,0.04)", borderColor: "rgba(160,80,255,0.25)" }}
            placeholder="Alt text / caption (optional)"
            value={newAlt} onChange={e => setNewAlt(e.target.value)}
          />
          <GoldButton onClick={add} disabled={saving || !newImg}>
            <Plus size={16} /> {saving ? "Uploading…" : "Add to Gallery"}
          </GoldButton>
        </div>

        {/* Gallery grid */}
        {items.length === 0 ? (
          <div className="rounded-2xl border py-14 text-center text-sm" style={{ background: T.card, borderColor: T.border, color: T.muted }}>
            No images yet. Upload one above.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {items.map(item => (
              <div key={item.id} className="relative group rounded-xl overflow-hidden" style={{ aspectRatio: "1" }}>
                <img src={item.imageUrl} alt={item.alt} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button onClick={() => del(item.id)} className="w-9 h-9 rounded-full bg-red-600 flex items-center justify-center">
                    <Trash2 size={16} color="#fff" />
                  </button>
                </div>
                {item.alt && (
                  <div className="absolute bottom-0 left-0 right-0 px-2 py-1 text-xs text-white bg-black/60 truncate">{item.alt}</div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
