import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import AdminLayout, { useAdminAuth, adminFetch } from "./AdminLayout";
import { Users, MessageSquare, Clock, CheckCircle } from "lucide-react";

interface Stats { total: number; newToday: number; pending: number; }
interface Inquiry {
  id: number; name: string; phone: string; service?: string;
  message: string; status: string; createdAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  new: "#e91e8c",
  contacted: "#7c3aed",
  resolved: "#16a34a",
  spam: "#6b7280",
};

export default function AdminDashboard() {
  const token = useAdminAuth();
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<Inquiry[]>([]);
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!token) return;
    adminFetch("/api/admin/stats").then(r => r.json()).then(setStats).catch(() => {});
    adminFetch("/api/admin/inquiries").then(r => r.json()).then((rows: Inquiry[]) => setRecent(rows.slice(0, 5))).catch(() => {});
  }, [token]);

  const statCards = [
    { label: "Total Inquiries", value: stats?.total ?? "—", icon: Users, color: "#e91e8c" },
    { label: "New Today", value: stats?.newToday ?? "—", icon: Clock, color: "#f59e0b" },
    { label: "Pending", value: stats?.pending ?? "—", icon: MessageSquare, color: "#7c3aed" },
    { label: "Resolved", value: stats ? (Number(stats.total) - Number(stats.pending)) : "—", icon: CheckCircle, color: "#16a34a" },
  ];

  return (
    <AdminLayout>
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-white/40 text-sm mt-1">Welcome back, Admin</p>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map((s) => (
            <div
              key={s.label}
              className="rounded-xl p-5 border border-primary/10 flex flex-col gap-3"
              style={{ background: "#1a0035" }}
            >
              <div className="flex items-center justify-between">
                <span className="text-white/50 text-xs font-medium">{s.label}</span>
                <s.icon size={18} style={{ color: s.color }} />
              </div>
              <p className="text-3xl font-bold text-white">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Recent inquiries */}
        <div className="rounded-xl border border-primary/10 overflow-hidden" style={{ background: "#1a0035" }}>
          <div className="flex items-center justify-between px-6 py-4 border-b border-primary/10">
            <h2 className="text-white font-semibold">Recent Inquiries</h2>
            <button
              onClick={() => setLocation("/admin/inquiries")}
              className="text-primary text-sm hover:underline"
              data-testid="link-view-all"
            >
              View all →
            </button>
          </div>

          {recent.length === 0 ? (
            <div className="py-12 text-center text-white/30">
              <MessageSquare className="mx-auto mb-3 opacity-30" size={32} />
              <p>No inquiries yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-primary/10">
                    <th className="text-left px-6 py-3 text-white/40 font-medium">Name</th>
                    <th className="text-left px-6 py-3 text-white/40 font-medium">Phone</th>
                    <th className="text-left px-6 py-3 text-white/40 font-medium hidden md:table-cell">Service</th>
                    <th className="text-left px-6 py-3 text-white/40 font-medium">Status</th>
                    <th className="text-left px-6 py-3 text-white/40 font-medium hidden lg:table-cell">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {recent.map((inq) => (
                    <tr key={inq.id} className="border-b border-primary/5 hover:bg-white/2">
                      <td className="px-6 py-3 text-white font-medium">{inq.name}</td>
                      <td className="px-6 py-3 text-white/70">{inq.phone}</td>
                      <td className="px-6 py-3 text-white/50 hidden md:table-cell capitalize">{inq.service ?? "—"}</td>
                      <td className="px-6 py-3">
                        <span
                          className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold text-white capitalize"
                          style={{ background: STATUS_COLORS[inq.status] ?? "#555" }}
                        >
                          {inq.status}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-white/40 text-xs hidden lg:table-cell">
                        {new Date(inq.createdAt).toLocaleDateString("en-IN")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}
