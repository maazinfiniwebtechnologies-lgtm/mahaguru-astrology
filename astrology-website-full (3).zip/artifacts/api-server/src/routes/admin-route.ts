import { Router } from "express";
import { db } from "@workspace/db";
import { inquiries, siteSettings } from "@workspace/db";
import { eq, desc, count, sql } from "drizzle-orm";
import { adminSessions, createSession, requireAdmin } from "../lib/auth";

const router = Router();

/* ── Auth ── */
router.post("/admin/login", (req, res) => {
  const { password } = req.body as { password?: string };
  if (!password) { res.status(400).json({ error: "Password required" }); return; }
  const token = createSession(password);
  if (!token) { res.status(401).json({ error: "Invalid password" }); return; }
  res.json({ token });
});

router.post("/admin/logout", requireAdmin, (req, res) => {
  adminSessions.delete(req.headers["x-admin-token"] as string);
  res.json({ ok: true });
});

/* ── Stats ── */
router.get("/admin/stats", requireAdmin, async (_req, res) => {
  const [total] = await db.select({ count: count() }).from(inquiries);
  const [newToday] = await db.select({ count: count() }).from(inquiries)
    .where(sql`created_at >= now() - interval '1 day'`);
  const [pending] = await db.select({ count: count() }).from(inquiries)
    .where(eq(inquiries.status, "new"));
  res.json({ total: total.count, newToday: newToday.count, pending: pending.count });
});

/* ── Inquiries ── */
router.get("/admin/inquiries", requireAdmin, async (_req, res) => {
  const rows = await db.select().from(inquiries).orderBy(desc(inquiries.createdAt)).limit(500);
  res.json(rows);
});
router.patch("/admin/inquiries/:id", requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  const { status } = req.body as { status: string };
  const allowed = ["new", "contacted", "resolved", "spam"];
  if (!allowed.includes(status)) { res.status(400).json({ error: "Invalid status" }); return; }
  const [row] = await db.update(inquiries).set({ status }).where(eq(inquiries.id, id)).returning();
  res.json(row);
});
router.delete("/admin/inquiries/:id", requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  await db.delete(inquiries).where(eq(inquiries.id, id));
  res.json({ ok: true });
});

/* ── Settings (key-value) ── */
router.get("/admin/settings", requireAdmin, async (_req, res) => {
  const rows = await db.select().from(siteSettings);
  const obj: Record<string, string> = {};
  for (const r of rows) obj[r.key] = r.value;
  res.json(obj);
});
router.put("/admin/settings", requireAdmin, async (req, res) => {
  const updates = req.body as Record<string, string>;
  for (const [key, value] of Object.entries(updates)) {
    await db.insert(siteSettings).values({ key, value })
      .onConflictDoUpdate({ target: siteSettings.key, set: { value, updatedAt: sql`now()` } });
  }
  res.json({ ok: true });
});

export default router;
