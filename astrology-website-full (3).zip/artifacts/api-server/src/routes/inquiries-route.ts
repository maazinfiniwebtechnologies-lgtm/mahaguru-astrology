import { Router } from "express";
import { db } from "@workspace/db";
import { inquiries, insertInquirySchema } from "@workspace/db";
import { desc } from "drizzle-orm";

const router = Router();

router.post("/inquiries", async (req, res) => {
  const parsed = insertInquirySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }
  const [row] = await db.insert(inquiries).values(parsed.data).returning();
  res.status(201).json(row);
});

export default router;
