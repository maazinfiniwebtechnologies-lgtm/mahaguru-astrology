import { Router, type IRouter } from "express";
import healthRouter from "./health";
import inquiriesRouter from "./inquiries-route";
import adminRouter from "./admin-route";
import crudRouter from "./crud-route";
import publicRouter from "./public-route";

const router: IRouter = Router();

router.use(healthRouter);
router.use(publicRouter);
router.use(inquiriesRouter);
router.use(adminRouter);
router.use(crudRouter);

export default router;
