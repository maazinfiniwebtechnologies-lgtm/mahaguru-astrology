import { Router } from "express";
import { db } from "@workspace/db";
import {
  services, insertServiceSchema,
  gallery, insertGallerySchema,
  testimonials, insertTestimonialSchema,
  faqs, insertFaqSchema,
  videoReviews, insertVideoReviewSchema,
} from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { requireAdmin } from "../lib/auth";

const router = Router();

function makeCrud(table: any, schema: any, orderCol?: any) {
  const r = Router();
  r.get("/", async (_req, res) => {
    const rows = orderCol
      ? await db.select().from(table).orderBy(asc(orderCol))
      : await db.select().from(table);
    res.json(rows);
  });
  r.post("/", requireAdmin, async (req, res) => {
    const p = schema.safeParse(req.body);
    if (!p.success) { res.status(400).json({ error: p.error.flatten() }); return; }
    const [row] = await db.insert(table).values(p.data).returning();
    res.status(201).json(row);
  });
  r.put("/:id", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const p = schema.partial().safeParse(req.body);
    if (!p.success) { res.status(400).json({ error: p.error.flatten() }); return; }
    const [row] = await db.update(table).set(p.data).where(eq(table.id, id)).returning();
    res.json(row);
  });
  r.delete("/:id", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    await db.delete(table).where(eq(table.id, id));
    res.json({ ok: true });
  });
  return r;
}

router.use("/admin/services", makeCrud(services, insertServiceSchema, services.displayOrder));
router.use("/admin/gallery", makeCrud(gallery, insertGallerySchema, gallery.displayOrder));
router.use("/admin/testimonials", makeCrud(testimonials, insertTestimonialSchema, testimonials.displayOrder));
router.use("/admin/faqs", makeCrud(faqs, insertFaqSchema, faqs.displayOrder));
router.use("/admin/video-reviews", makeCrud(videoReviews, insertVideoReviewSchema, videoReviews.displayOrder));

export default router;
