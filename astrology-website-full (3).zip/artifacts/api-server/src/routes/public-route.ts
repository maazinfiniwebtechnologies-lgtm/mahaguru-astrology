import { Router } from "express";
import { db } from "@workspace/db";
import { services, gallery, testimonials, faqs, videoReviews, siteSettings } from "@workspace/db";
import { eq, asc } from "drizzle-orm";

const router = Router();

router.get("/settings", async (_req, res) => {
  const rows = await db.select().from(siteSettings);
  const obj: Record<string, string> = {};
  for (const r of rows) obj[r.key] = r.value;
  res.json(obj);
});

router.get("/services", async (_req, res) => {
  const rows = await db.select().from(services)
    .where(eq(services.active, true))
    .orderBy(asc(services.displayOrder));
  res.json(rows);
});

router.get("/gallery", async (_req, res) => {
  const rows = await db.select().from(gallery)
    .orderBy(asc(gallery.displayOrder));
  res.json(rows);
});

router.get("/testimonials", async (_req, res) => {
  const rows = await db.select().from(testimonials)
    .where(eq(testimonials.active, true))
    .orderBy(asc(testimonials.displayOrder));
  res.json(rows);
});

router.get("/faqs", async (_req, res) => {
  const rows = await db.select().from(faqs)
    .where(eq(faqs.active, true))
    .orderBy(asc(faqs.displayOrder));
  res.json(rows);
});

router.get("/video-reviews", async (_req, res) => {
  const rows = await db.select().from(videoReviews)
    .where(eq(videoReviews.active, true))
    .orderBy(asc(videoReviews.displayOrder));
  res.json(rows);
});

export default router;
