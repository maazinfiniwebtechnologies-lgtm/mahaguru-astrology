import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";

export const adminSessions = new Set<string>();

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "astroguru@2024";

export function createSession(password: string): string | null {
  if (password !== ADMIN_PASSWORD) return null;
  const token = crypto.randomUUID();
  adminSessions.add(token);
  return token;
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token || !adminSessions.has(token)) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}
